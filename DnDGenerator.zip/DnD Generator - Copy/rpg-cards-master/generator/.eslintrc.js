module.exports = {
    "env": {
        "browser": true
    },
    "rules": {
        "semi": ["error", "always"],
        "eqeqeq": ["error", "smart"]
    }
};